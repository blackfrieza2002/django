from django.contrib import admin
from django.urls import path
from test import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",views.home),
    path("upload/image",views.upload_image),
]
