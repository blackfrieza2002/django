import base64
import json
from django.http import JsonResponse
from django.shortcuts import render


def home(request):
    return render(request, 'index.html')


def upload_image(request):
    if request.method == "POST":
        body = json.loads(request.body)
        image_data = body.get('image_data')

        if not image_data:
            return JsonResponse({'status': 'error', 'message': 'No image data'}, status=400)

        format_str, imgstr = image_data.split(';base64,')
        ext = format_str.split('/')[-1]
        data = base64.b64decode(imgstr)

        with open(f'image.{ext}', 'wb') as f:
            f.write(data)

        return JsonResponse({'status': 'success'})

    return JsonResponse({'status': 'error', 'message': 'POST required'}, status=405)

